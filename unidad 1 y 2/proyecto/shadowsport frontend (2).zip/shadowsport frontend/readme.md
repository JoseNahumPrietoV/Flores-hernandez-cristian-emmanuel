# 🏅 ShadowSport - E-Commerce Platform

Plataforma de comercio electrónico de alto rendimiento para artículos deportivos, desarrollada con una arquitectura moderna separada (Frontend/Backend) y despliegue en la nube.

## 🚀 Tecnologías Utilizadas

### Frontend (Presentación)
* **HTML5 & CSS3:** Estructura semántica y diseño responsivo.
* **Bootstrap 5:** Sistema de grillas y componentes de UI rápidos.
* **Vanilla JavaScript (ES6+):** Lógica del lado del cliente, consumo de API y manejo del DOM.
* **AOS (Animate On Scroll):** Microinteracciones y animaciones de interfaz.

### Backend (Lógica de Negocios & API)
* **Node.js & Express:** Servidor de alto rendimiento y enrutamiento RESTful.
* **MongoDB:** Base de datos NoSQL para gestión flexible de catálogos y órdenes.
* **JWT (JSON Web Tokens):** Autenticación y autorización segura por roles (Admin/Cliente).
* **Bcrypt.js:** Encriptación y hashing de contraseñas.

### Integraciones de Terceros
* **Stripe API:** Pasarela de pagos segura en entorno Sandbox.
* **Google Apps Script API:** Microservicio Serverless para la evasión de firewalls en correos transaccionales y recuperación de contraseñas.

## ⚙️ Características Principales
1. **Catálogo Dinámico:** Filtrado en tiempo real y carga dinámica desde base de datos.
2. **Gestión de Sesiones:** Recuperación de contraseñas con tokens temporales seguros.
3. **Checkout Seguro:** Integración con Stripe para procesamiento de pagos.
4. **Intranet Administrativa:** Panel de control para empleados, actualización de estatus de órdenes y aplicación de ofertas.
5. **Notificaciones Automáticas:** Envío de correos electrónicos transaccionales al cambiar el estado de un pedido.