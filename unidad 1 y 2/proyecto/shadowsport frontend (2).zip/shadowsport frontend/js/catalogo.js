// ==========================================
// CONFIGURACIÓN INICIAL
// ==========================================
const API_URL = 'https://shadowsport.onrender.com/api';
let carrito = JSON.parse(localStorage.getItem('shadow_carrito')) || [];
let productosGenerales = []; 

const parametrosURL = new URLSearchParams(window.location.search);
const filtroGenero = parametrosURL.get('genero'); 
const filtroOfertas = parametrosURL.get('ofertas'); 

// ==========================================
// CARGA DE DATOS Y TÍTULOS
// ==========================================
async function cargarCatalogo() {
    actualizarContadorCarrito();
    ajustarTitulo();

    try {
        const respuesta = await fetch(`${API_URL}/products`);
        let productos = await respuesta.json();

        if (filtroGenero) {
            productosGenerales = productos.filter(p => p.gender && p.gender.toLowerCase() === filtroGenero.toLowerCase());
        } else if (filtroOfertas) {
            productosGenerales = productos.filter(p => p.is_offer === true);
        } else {
            productosGenerales = productos; 
        }

        aplicarFiltrosMaestro();
    } catch (error) {
        document.getElementById('contenedor-productos').innerHTML = '<h5 class="text-danger">Error de conexión con el servidor.</h5>';
    }
}

function ajustarTitulo() {
    const titulo = document.getElementById('titulo-pagina');
    if (filtroGenero) titulo.innerHTML = `EXPLORA <span style="color: var(--accent-gold);">${filtroGenero.toUpperCase()}</span>`;
    else if (filtroOfertas) titulo.innerHTML = `🔥 ZONA DE <span style="color: var(--accent-gold);">OFERTAS</span>`;
    else titulo.innerHTML = `CATÁLOGO <span style="color: var(--accent-gold);">COMPLETO</span>`;
}

// ==========================================
// CEREBRO DE FILTROS AVANZADOS
// ==========================================
let categoriaActiva = 'Todo';

function cambiarCategoria(seccionElegida, btnElemento) {
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    btnElemento.classList.add('active');
    categoriaActiva = seccionElegida;
    aplicarFiltrosMaestro(); 
}

function actualizarPrecio() {
    document.getElementById('valor-precio').innerText = document.getElementById('rango-precio').value;
}

function aplicarFiltrosMaestro() {
    const textoBuscado = document.getElementById('input-busqueda').value.toLowerCase();
    const precioMaximo = parseFloat(document.getElementById('rango-precio').value);

    const productosFiltrados = productosGenerales.filter(prod => {
        const nombreValido = prod.name ? prod.name.toLowerCase().includes(textoBuscado) : false;
        const catValida = prod.category ? prod.category.toLowerCase().includes(textoBuscado) : false;
        const pasaTexto = nombreValido || catValida;
        
        const pasaDepartamento = (categoriaActiva === 'Todo') || (prod.section === categoriaActiva);
        const pasaPrecio = parseFloat(prod.price) <= precioMaximo;

        return pasaTexto && pasaDepartamento && pasaPrecio;
    });

    renderizarCatalogo(productosFiltrados);
}

// ==========================================
// DIBUJAR TARJETAS Y MODAL (VERSIÓN CON OFERTAS)
// ==========================================
function renderizarCatalogo(productos) {
    const contenedor = document.getElementById('contenedor-productos');
    contenedor.innerHTML = '';

    if (productos.length === 0) {
        contenedor.innerHTML = '<div class="col-12 text-center py-5"><h5 style="color: #A0ABC0; font-weight: 600;">No hay productos en esta categoría por ahora. 🕵️‍♂️</h5></div>';
        return;
    }

    productos.forEach(prod => {
        const imgSegura = prod.image_url || 'https://placehold.co/400x400/151A22/D4AF37?text=S';
        
        // 1. LÓGICA DE PRECIOS Y OFERTAS
        let precioFinal = parseFloat(prod.price);
        let precioHTML = `<span class="product-price fw-bold">$${precioFinal.toFixed(2)}</span>`;
        let badgeHtml = '';

        // Si está en oferta (verificamos true booleano o texto) y tiene precio de oferta
        if ((prod.onSale === true || prod.onSale === 'true') && prod.salePrice) {
            precioFinal = parseFloat(prod.salePrice); // Este es el precio que va al carrito
      
           // Tachamos el original y ponemos el nuevo
            precioHTML = `
                <div class="d-flex flex-column text-end">
                    <span class="text-decoration-line-through" style="color: #A0ABC0; font-size: 0.85rem; font-weight: 500;">$${parseFloat(prod.price).toFixed(2)}</span>
                    <span class="product-price text-warning fw-bold">$${precioFinal.toFixed(2)}</span>
                </div>
            `;
            // Forzamos el badge de oferta visualmente
            badgeHtml = `<span class="badge bg-danger position-absolute top-0 start-0 m-2 px-2 py-1 fs-6 rounded-1">🔥 OFERTA</span>`;
        } else if (prod.category && prod.category.toLowerCase().includes('pro')) {
            badgeHtml = `<span class="badge bg-primary position-absolute top-0 start-0 m-2 px-2 py-1 fs-6 rounded-1">PRO</span>`;
        }

        contenedor.innerHTML += `
            <div class="col">
                <div class="product-card d-flex flex-column position-relative">
                    <div class="product-img-wrapper" style="cursor: pointer;" onclick="abrirDetalleProducto('${prod._id}')">
                        ${badgeHtml}
                        <img src="${imgSegura}" alt="${prod.name}" class="product-img w-100 rounded-top">
                    </div>
                    <div class="d-flex flex-column flex-grow-1 mt-2">
                        <h5 class="product-title text-white">${prod.name}</h5>
                        <p class="product-category text-secondary">${prod.category} • ${(prod.gender || 'Unisex').toUpperCase()}</p>
                        
                        <div class="mt-auto d-flex justify-content-between align-items-end">
                            ${precioHTML}
                            <button id="btn-${prod._id}" class="btn-add btn btn-sm btn-outline-warning fw-bold" onclick="agregarAlCarrito('${prod._id}', '${prod.name}', ${precioFinal}, '${imgSegura}', this.id)">
                                AGREGAR
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
}

function abrirDetalleProducto(id) {
    const prod = productosGenerales.find(p => p._id === id);
    if(!prod) return;

    // 🔍 EL DETECTIVE: Esto imprimirá el producto en tu consola (F12)
    console.log("🔍 DATOS DEL PRODUCTO SELECCIONADO:", prod);

    const imgSegura = prod.image_url || 'https://placehold.co/400x400/151A22/D4AF37?text=S';

    document.getElementById('detalle-img').src = imgSegura;
    document.getElementById('detalle-nombre').innerText = prod.name;
    document.getElementById('detalle-categoria').innerText = `${prod.category} • ${(prod.gender || 'Unisex').toUpperCase()}`;
    document.getElementById('detalle-desc').innerText = prod.description || 'Sin descripción detallada disponible.';

    let precioFinal = parseFloat(prod.price);
    let precioHTML = `$${precioFinal.toFixed(2)}`;

    // 🛡️ LÓGICA BLINDADA: Buscamos cualquier posible nombre que tenga la oferta
    const estaEnOferta = prod.onSale === true || prod.onSale === 'true' || prod.is_offer === true || prod.en_oferta === true;
    const precioOferta = prod.salePrice || prod.sale_price || prod.precio_de_venta;

    if (estaEnOferta && precioOferta) {
        precioFinal = parseFloat(precioOferta);
        precioHTML = `
            <span class="text-decoration-line-through fs-5 me-2" style="color: #A0ABC0; font-weight: 500;">$${parseFloat(prod.price).toFixed(2)}</span>
            <span class="text-warning fw-bold fs-3">$${precioFinal.toFixed(2)}</span>
        `;
    }

    document.getElementById('detalle-precio').innerHTML = precioHTML;

    const btnAgregar = document.getElementById('detalle-btn-agregar');
    btnAgregar.onclick = () => {
        agregarAlCarrito(prod._id, prod.name, precioFinal, imgSegura, 'detalle-btn-agregar');
    };

    const modal = new bootstrap.Modal(document.getElementById('modalDetalleProducto'));
    modal.show();
}

// ==========================================
// CARRITO DE COMPRAS
// ==========================================
function agregarAlCarrito(id, nombre, precio, imagen, btnId) {
    carrito.push({ producto: nombre, cantidad: 1, precio: precio, id_producto: id, imagen: imagen });
    localStorage.setItem('shadow_carrito', JSON.stringify(carrito));
    
    actualizarContadorCarrito();
    
    const btn = document.getElementById(btnId);
    btn.innerText = "¡AÑADIDO!";
    btn.style.backgroundColor = "var(--accent-gold)";
    btn.style.color = "black";
    
    setTimeout(() => {
        btn.innerText = "AGREGAR";
        btn.style.backgroundColor = "transparent";
        btn.style.color = "var(--accent-gold)";
    }, 1000);
}

function actualizarContadorCarrito() {
    document.getElementById('btn-carrito-nav').innerText = `🛒 CARRITO (${carrito.length})`;
}

// ==========================================
// ANIMACIÓN DEL ICONO Y ARRANQUE
// ==========================================
const panelFiltros = document.getElementById('panelFiltros');
const icono = document.getElementById('icono-filtro');

if (panelFiltros && icono) {
    panelFiltros.addEventListener('show.bs.collapse', () => { icono.innerText = '➖'; });
    panelFiltros.addEventListener('hide.bs.collapse', () => { icono.innerText = '➕'; });
}

// Iniciar la página
cargarCatalogo();