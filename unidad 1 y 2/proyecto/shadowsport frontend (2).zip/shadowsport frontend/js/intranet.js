const API_URL = 'https://shadowsport.onrender.com/api';
const token = localStorage.getItem('shadow_token');
const rol = localStorage.getItem('shadow_rol');

// 1. Validar que sea un empleado de verdad
if (!token || rol !== 'empleado') {
    window.location.href = 'login.html';
}

function cerrarSesion() {
    localStorage.removeItem('shadow_token');
    localStorage.removeItem('shadow_rol');
    window.location.href = 'login.html';
}

// 2. Cargar todas las órdenes
async function cargarOrdenes() {
    try {
        const respuesta = await fetch(`${API_URL}/orders/todas`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (!respuesta.ok) throw new Error("Status HTTP: " + respuesta.status);
        
        const ordenes = await respuesta.json();
        console.log("📦 Órdenes recibidas del servidor:", ordenes); // Muestra los datos crudos
        renderizarTabla(ordenes);
    } catch (error) {
        console.error("❌ Error exacto capturado:", error); // Ahora sí nos dirá qué falló
        document.getElementById('tabla-pedidos').innerHTML = `<tr><td colspan="6" class="text-center text-danger py-4">Error interno al dibujar la tabla. Revisa la consola (F12).</td></tr>`;
    }
}

// 3. Dibujar la tabla (VERSIÓN A PRUEBA DE BALAS)
function renderizarTabla(ordenes) {
    const tbody = document.getElementById('tabla-pedidos');
    tbody.innerHTML = '';

    // Verificamos que sí sea una lista válida
    if (!Array.isArray(ordenes) || ordenes.length === 0) {
        tbody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-muted">No hay órdenes registradas.</td></tr>`;
        return;
    }

    ordenes.forEach(orden => {
        // PROTECCIONES CONTRA DATOS VIEJOS DE MONGODB
        const idSeguro = orden._id ? orden._id.toString() : 'SIN-ID';
        const idCorto = idSeguro.substring(0, 8).toUpperCase();
        const fecha = orden.date ? new Date(orden.date).toLocaleDateString('es-MX') : 'Sin fecha';
        const estado = orden.status || 'Pendiente de Envío'; // Si no tiene estado, le pone pendiente
        const total = orden.total ? parseFloat(orden.total).toFixed(2) : '0.00';
        const correo = orden.user_email || 'Sin correo';
  

        // Colores del estado
        let colorBadge = 'bg-secondary';
        if (estado === 'Pendiente de Envío') colorBadge = 'bg-warning text-dark';
        if (estado === 'Pagado') colorBadge = 'bg-info text-dark'; // Color para Pagado
        if (estado === 'En Camino') colorBadge = 'bg-primary';
        if (estado === 'Entregado') colorBadge = 'bg-success';

        tbody.innerHTML += `
            <tr>
                <td class="fw-bold text-muted">#${idCorto}</td>
                <td>${fecha}</td>
                <td>${correo}</td>
                <td style="color: var(--accent-gold); font-weight: bold;">$${total}</td>
                <td><span class="badge ${colorBadge}">${estado.toUpperCase()}</span></td>
                <td>
                    <div class="d-flex gap-2">
                        <select id="select-${idSeguro}" class="form-select form-select-sm form-select-dark w-auto">
                            <option value="Pendiente de Envío" ${estado === 'Pendiente de Envío' ? 'selected' : ''}>Pendiente</option>
                            <option value="Pagado" ${estado === 'Pagado' ? 'selected' : ''}>Pagado 💳</option>
                            <option value="En Camino" ${estado === 'En Camino' ? 'selected' : ''}>En Camino 🚚</option>
                            <option value="Entregado" ${estado === 'Entregado' ? 'selected' : ''}>Entregado ✅</option>
                        </select>
                        <button onclick="actualizarEstado('${idSeguro}')" class="btn btn-sm btn-outline-light fw-bold">GUARDAR</button>
                    </div>
                </td>
            </tr>
        `;
    });
}

// 4. Actualizar el estado en la Base de Datos
async function actualizarEstado(idOrden) {
    if (idOrden === 'SIN-ID') return alert('No se puede actualizar una orden sin ID');
    
    const nuevoEstado = document.getElementById(`select-${idOrden}`).value;
    
    try {
        const respuesta = await fetch(`${API_URL}/orders/${idOrden}/estado`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ status: nuevoEstado })
        });

        if (respuesta.ok) {
            alert('✅ Estado actualizado con éxito');
            cargarOrdenes(); 
        } else {
            alert('❌ Error al actualizar');
        }
    } catch (error) {
        alert('❌ Error de conexión');
    }
}

// Arrancar
cargarOrdenes();

// ==========================================
// SECCIÓN: CATÁLOGO Y OFERTAS
// ==========================================

async function cargarCatalogo() {
    try {
        // Asumiendo que tu ruta de productos es /api/products o /api/productos
        const respuesta = await fetch(`${API_URL}/products`); 
        if (!respuesta.ok) throw new Error("Error al cargar productos");
        
        const productos = await respuesta.json();
        renderizarTablaProductos(productos);
    } catch (error) {
        document.getElementById('tabla-productos').innerHTML = `<tr><td colspan="5" class="text-center text-danger py-4">Error al cargar el catálogo.</td></tr>`;
    }
}

function renderizarTablaProductos(productos) {
    const tbody = document.getElementById('tabla-productos');
    tbody.innerHTML = '';

    if (!Array.isArray(productos) || productos.length === 0) return tbody.innerHTML = `<tr><td colspan="5" class="text-center py-4">No hay productos.</td></tr>`;

    productos.forEach(prod => {
        const idSeguro = prod._id ? prod._id.toString() : 'SIN-ID';
        const enOferta = prod.onSale || false; // ¿Está en oferta?
        const precioOferta = prod.salePrice || prod.price;

        tbody.innerHTML += `
            <tr>
                <td class="fw-bold">${prod.name || 'Producto'}</td>
                <td class="text-muted">$${parseFloat(prod.price).toFixed(2)}</td>
                <td>
                    <select id="oferta-${idSeguro}" class="form-select form-select-sm form-select-dark w-auto">
                        <option value="false" ${!enOferta ? 'selected' : ''}>Normal</option>
                        <option value="true" ${enOferta ? 'selected' : ''}>🔥 En Oferta</option>
                    </select>
                </td>
                <td>
                    <input type="number" id="precio-${idSeguro}" class="form-control form-control-sm premium-input w-75" value="${parseFloat(precioOferta).toFixed(2)}">
                </td>
                <td>
                    <button onclick="guardarOferta('${idSeguro}')" class="btn btn-sm btn-outline-warning fw-bold">APLICAR</button>
                </td>
            </tr>
        `;
    });
}

async function guardarOferta(idProducto) {
    // 1. Limpiamos el ID por si trae espacios o caracteres raros
    const idLimpio = idProducto.trim();
    
    // 2. Obtenemos los valores de los inputs
    const selectOferta = document.getElementById(`oferta-${idLimpio}`);
    const inputPrecio = document.getElementById(`precio-${idLimpio}`);

    if (!selectOferta || !inputPrecio) {
        return alert("❌ Error: No se encontraron los controles del producto.");
    }

    const estaEnOferta = selectOferta.value === 'true';
    const nuevoPrecioOferta = parseFloat(inputPrecio.value);

    try {
        const respuesta = await fetch(`${API_URL}/products/${idLimpio}/oferta`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ 
                onSale: estaEnOferta, 
                salePrice: nuevoPrecioOferta 
            })
        });

        const data = await respuesta.json();

        if (respuesta.ok) {
            alert('✅ ¡Oferta aplicada correctamente!');
            cargarCatalogo(); 
        } else {
            // Si el servidor dice "sin cambios", vamos a ser más descriptivos
            console.warn("Respuesta del servidor:", data);
            alert(`⚠️ No se pudo actualizar: ${data.error || 'Verifica si hubo cambios reales'}`);
        }
    } catch (error) {
        console.error("🚨 Error en la petición:", error);
        alert('❌ Error de comunicación con el servidor.');
    }
}

// Arrancar ambas cosas
cargarCatalogo();