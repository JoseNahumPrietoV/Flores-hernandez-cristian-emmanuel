const API_URL = 'https://shadowsport.onrender.com/api';

// Leemos el carrito y el token
let carritoCheckout = JSON.parse(localStorage.getItem('shadow_carrito')) || [];
const tokenCliente = localStorage.getItem('shadow_token');

document.addEventListener("DOMContentLoaded", () => {
    // 1. Verificaciones de seguridad
    if (carritoCheckout.length === 0) {
        alert("Tu carrito está vacío.");
        window.location.href = 'index.html';
        return;
    }
    if (!tokenCliente) {
        alert("Debes iniciar sesión para finalizar tu compra.");
        window.location.href = 'login.html';
        return;
    }

    // 2. Pintar los productos en el resumen
    renderizarResumen();
});

function renderizarResumen() {
    const contenedor = document.getElementById('contenedor-resumen');
    let subtotal = 0;
    contenedor.innerHTML = '';

    carritoCheckout.forEach(item => {
        subtotal += (item.precio * item.cantidad);
        
        contenedor.innerHTML += `
            <div class="summary-item">
                <div class="d-flex align-items-center gap-3">
                    <img src="${item.imagen}" alt="${item.producto}">
                    <div>
                        <div class="fw-bold" style="font-size: 0.9rem;">${item.producto}</div>
                        <small class="text-muted">Cant: ${item.cantidad}</small>
                    </div>
                </div>
                <div class="fw-bold">$${(item.precio * item.cantidad).toFixed(2)}</div>
            </div>
        `;
    });

    document.getElementById('resumen-subtotal').innerText = `$${subtotal.toFixed(2)}`;
    document.getElementById('resumen-total').innerText = `$${subtotal.toFixed(2)}`;
}

// 3. ENVIAR EL PEDIDO A LA BASE DE DATOS Y A STRIPE
document.getElementById('form-checkout').addEventListener('submit', async (e) => {
    e.preventDefault();

    const btnPagar = document.getElementById('btn-pagar');
    btnPagar.innerText = "Conectando al banco seguro...";
    btnPagar.disabled = true;

    const totalPedido = carritoCheckout.reduce((sum, item) => sum + (item.precio * item.cantidad), 0);

    const ordenData = {
        items: carritoCheckout.map(item => ({ 
            product_id: item.id_producto,
            name: item.producto,
            quantity: item.cantidad,
            price: item.precio
        })),
        total: totalPedido, 
        shipping_address: `${document.getElementById('envio-direccion').value}, ${document.getElementById('envio-ciudad').value}, CP: ${document.getElementById('envio-cp').value}`,
        payment_method: "Stripe - Tarjeta"
    };

    try {
        // PASO 1: Guardamos la orden en la base de datos de ShadowSport
        const respuestaOrden = await fetch(`${API_URL}/orders`, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${tokenCliente}` 
            },
            body: JSON.stringify(ordenData)
        });

        if (!respuestaOrden.ok) {
            throw new Error("No se pudo registrar la orden en la base de datos.");
        }

        // PASO 2: Llamamos a Stripe para generar la pantalla de cobro
        const respuestaStripe = await fetch(`${API_URL}/create-checkout-session`, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json' 
            },
            body: JSON.stringify({ carrito: carritoCheckout })
        });

        const dataStripe = await respuestaStripe.json();

        // PASO 3: Redirigir a la pasarela de Stripe
        if (dataStripe.url) {
            window.location.href = dataStripe.url; 
        } else {
            alert("Error al iniciar el pago con Stripe.");
            btnPagar.innerText = "Pagar Ahora";
            btnPagar.disabled = false;
        }

    } catch (error) {
        console.error("Error crítico en el proceso de pago:", error);
        alert("Error de conexión con el servidor. Intenta de nuevo.");
        btnPagar.innerText = "Pagar Ahora";
        btnPagar.disabled = false;
    }
});