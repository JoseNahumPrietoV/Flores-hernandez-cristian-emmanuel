const API_URL = 'https://shadowsport.onrender.com/api';

document.addEventListener("DOMContentLoaded", () => {
    const formLogin = document.getElementById('form-login');
    const msjError = document.getElementById('login-error');
    
    // Capturamos el botón para hacer el efecto de "Cargando..."
    const btnSubmit = document.querySelector('#form-login button[type="submit"]');

    // 1. VALIDACIÓN INICIAL: Si ya tiene token, lo mandamos a su área correspondiente
    if (localStorage.getItem('shadow_token')) {
        const rolGuardado = localStorage.getItem('shadow_rol');
        redirigirPorRol(rolGuardado);
    }

    if (formLogin) {
        formLogin.addEventListener('submit', async (e) => {
            e.preventDefault(); 
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            // Ocultamos el error al intentar de nuevo y ponemos estado de carga
            msjError.style.display = 'none';
            if(btnSubmit) btnSubmit.innerText = "VERIFICANDO...";

            try {
                // Petición a tu ruta original
                const respuesta = await fetch(`${API_URL}/auth/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });

                const datos = await respuesta.json();

                if (respuesta.ok) {
                    // ¡ÉXITO! Guardamos Token y Rol
                    localStorage.setItem('shadow_token', datos.token);
                    localStorage.setItem('shadow_rol', datos.role);

                    // === NUEVA LÓGICA PARA PROVEEDORES ===
                    if (datos.role === 'proveedor') {
                        // Extraemos la marca del correo (ej: admin@nike.com -> nike)
                        const marca = email.split('@')[1].split('.')[0];
                        localStorage.setItem('shadow_proveedor_marca', marca);
                    }
                    
                    // Usamos la función cadenero
                    redirigirPorRol(datos.role);
                } else {
                    msjError.innerText = "❌ " + (datos.error || "Credenciales incorrectas");
                    msjError.style.display = 'block';
                    if(btnSubmit) btnSubmit.innerText = "INICIAR SESIÓN";
                }
            } catch (error) {
                msjError.innerText = "❌ Error de conexión con el servidor.";
                msjError.style.display = 'block';
                if(btnSubmit) btnSubmit.innerText = "INICIAR SESIÓN";
            }
        });
    }
});

// ==========================================
// FUNCIÓN CADENERO: RUTAS POR ROL
// ==========================================
function redirigirPorRol(rol) {
    if (rol === 'admin') {
        window.location.href = 'admin.html';       // El jefe supremo
    } else if (rol === 'empleado') {
        window.location.href = 'intranet.html';    // Panel interno (paquetería/atención)
    } else if (rol === 'proveedor') {
        window.location.href = 'extranet.html';    // Panel externo (proveedores de stock)
    } else {
        window.location.href = 'index.html';       // Cliente normal o sin rol
    }
}

// ==========================================
// FUNCIÓN RECUPERAR CONTRASEÑA
// (Declarada en window para que el HTML la pueda llamar)
// ==========================================
window.enviarRecuperacion = function() {
    const email = document.getElementById('email-recuperar').value;
    const msj = document.getElementById('msg-recuperar');
    const btn = document.getElementById('btn-recuperar');

    if(!email) {
        msj.innerText = "Por favor ingresa tu correo.";
        msj.className = "mt-3 text-center small fw-bold py-2 rounded bg-danger text-white";
        msj.classList.remove('d-none');
        return;
    }

    btn.innerText = "ENVIANDO...";
    btn.disabled = true;

    // Simulación del envío de correo
    setTimeout(() => {
        msj.innerText = "✅ Enlace enviado. Revisa tu bandeja de entrada.";
        msj.className = "mt-3 text-center small fw-bold py-2 rounded bg-success text-white";
        msj.classList.remove('d-none');
        
        btn.innerText = "ENVIAR ENLACE";
        btn.disabled = false;
        document.getElementById('email-recuperar').value = '';
    }, 1500);
};