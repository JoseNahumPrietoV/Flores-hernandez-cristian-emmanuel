// ==========================================
// js/extranet.js - LOGIN DE PROVEEDORES
// ==========================================
const API_URL = 'https://shadowsport.onrender.com/api';

document.addEventListener('DOMContentLoaded', () => {
    const formLogin = document.getElementById('form-extranet-login');
    
    if(formLogin) {
        formLogin.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email-proveedor').value.trim();
            const password = document.getElementById('pass-proveedor').value;
            const btnLogin = document.getElementById('btn-login');

            btnLogin.innerText = "VERIFICANDO CREDENCIALES B2B...";
            btnLogin.disabled = true;

            try {
                // Llamamos a tu ruta de login existente
                const respuesta = await fetch(`${API_URL}/auth/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password })
                });

                const data = await respuesta.json();

                if (respuesta.ok) {
                    // EL FILTRO MAESTRO: Verificamos que realmente sea un proveedor
                    if (data.user.role === 'proveedor') {
                        // Guardamos el token y los datos de la marca
                        localStorage.setItem('shadow_extranet_token', data.token);
                        // Suponiendo que el email indica su marca (ej. admin@nike.com)
                        localStorage.setItem('shadow_proveedor_marca', email.split('@')[1].split('.')[0]); 
                        
                        window.location.href = 'extranet-dashboard.html'; // Lo mandamos a su panel
                    } else {
                        alert("⛔ ACCESO DENEGADO: Este portal es exclusivo para proveedores B2B. Tu rol actual es: " + data.user.role.toUpperCase());
                        btnLogin.innerText = "INGRESAR AL INVENTARIO";
                        btnLogin.disabled = false;
                    }
                } else {
                    alert("Credenciales incorrectas: " + data.message);
                    btnLogin.innerText = "INGRESAR AL INVENTARIO";
                    btnLogin.disabled = false;
                }
            } catch (error) {
                console.error("Error de servidor:", error);
                alert("Error de conexión con el servidor ShadowSport.");
                btnLogin.innerText = "INGRESAR AL INVENTARIO";
                btnLogin.disabled = false;
            }
        });
    }
});