// ==========================================
// js/extranet-dashboard.js - VERSIÓN FINAL
// ==========================================
const API_URL = 'https://shadowsport.onrender.com/api';

// 1. Obtenemos los datos que guardó el login
const token = localStorage.getItem('shadow_token');
const marcaProveedor = localStorage.getItem('shadow_proveedor_marca');

// Seguridad: Si no hay token o no es proveedor, para afuera
if (!token || !marcaProveedor) {
    alert("Sesión inválida o expirada.");
    window.location.href = 'login.html';
}

document.addEventListener('DOMContentLoaded', () => {
    // Ponemos el nombre de la marca en el título
    document.getElementById('brand-name').innerText = marcaProveedor.toUpperCase();
    
    // Cargamos los tenis
    cargarInventarioMarca(marcaProveedor);
});

async function cargarInventarioMarca(marca) {
    try {
        const respuesta = await fetch(`${API_URL}/products`);
        const todosLosProductos = await respuesta.json();

        // FILTRO: Solo mostramos lo que coincida con la marca guardada
        const misProductos = todosLosProductos.filter(prod => {
            // Comparamos ignorando mayúsculas/minúsculas
            return prod.brand && prod.brand.toLowerCase() === marca.toLowerCase();
        });

        dibujarTabla(misProductos);
    } catch (error) {
        console.error("Error B2B:", error);
        document.getElementById('tabla-inventario').innerHTML = `<tr><td colspan="5" class="text-center text-danger py-4">Error de conexión con el servidor.</td></tr>`;
    }
}

function dibujarTabla(productos) {
    const tbody = document.getElementById('tabla-inventario');
    document.getElementById('total-productos').innerText = productos.length;
    tbody.innerHTML = '';

    if (productos.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" class="text-center py-5 text-muted">No hay productos registrados para la marca ${marcaProveedor.toUpperCase()}.</td></tr>`;
        return;
    }

    productos.forEach(prod => {
        const imgSegura = prod.image_url || 'https://placehold.co/100x100/151A22/D4AF37?text=S';
        
        let htmlStock = `<span class="badge-stock fw-bold">EN EXISTENCIA</span>`;
        if (prod.stock_status === 'low_stock' || prod.stock_status === 'out_of_stock') {
            htmlStock = `<span class="badge-low-stock fw-bold">RESURTIR PRONTO</span>`;
        }

        tbody.innerHTML += `
            <tr>
                <td style="width: 80px;">
                    <img src="${imgSegura}" alt="${prod.name}" class="rounded" style="width: 50px; height: 50px; object-fit: cover;">
                </td>
                <td>
                    <div class="fw-bold text-white">${prod.name}</div>
                    <div class="small text-muted">ID: ${prod._id}</div>
                </td>
                <td>${prod.category}</td>
                <td class="fw-bold" style="color: #D4AF37;">$${parseFloat(prod.price).toFixed(2)}</td>
                <td>${htmlStock}</td>
            </tr>
        `;
    });
}

function cerrarSesionProveedor() {
    localStorage.clear(); // Limpiamos todo
    window.location.href = 'login.html';
}