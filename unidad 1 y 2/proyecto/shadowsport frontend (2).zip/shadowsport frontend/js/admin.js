// ==========================================
// js/admin.js - LÓGICA DEL DASHBOARD COMPLETO (VERSIÓN BLINDADA)
// ==========================================

const API_URL = 'https://shadowsport.onrender.com/api';

// 1. Protección de Ruta (Solo para admins logueados)
const token = localStorage.getItem('shadow_token');
if (!token) {
    window.location.href = 'login.html'; // Si no hay sesión, pa' fuera
}

// Variables globales en memoria
let listaProductosGlobal = []; 
let listaUsuariosGlobal = [];

document.addEventListener("DOMContentLoaded", () => {
    // Iniciamos mostrando el inventario
    mostrarSeccion('inventario');

    // Escuchar el formulario de agregar producto
    const formNuevo = document.getElementById('form-nuevo-producto');
    if(formNuevo) formNuevo.addEventListener('submit', guardarProducto);
});

// ==========================================
// SISTEMA DE NAVEGACIÓN (Pestañas)
// ==========================================
function mostrarSeccion(seccion) {
    // Apagamos TODAS las secciones
    document.getElementById('seccion-inventario').style.display = 'none';
    document.getElementById('seccion-usuarios').style.display = 'none';
    document.getElementById('seccion-pedidos').style.display = 'none';

    // Prendemos la que el usuario eligió
    const secElement = document.getElementById('seccion-' + seccion);
    if(secElement) secElement.style.display = 'block';

    // Quitamos el color dorado de todos los botones
    document.getElementById('menu-inventario').classList.remove('active');
    document.getElementById('menu-usuarios').classList.remove('active');
    document.getElementById('menu-pedidos').classList.remove('active');

    // Ponemos color dorado solo al botón presionado
    const btnElement = document.getElementById('menu-' + seccion);
    if(btnElement) btnElement.classList.add('active');

    // Disparamos la carga de datos según la sección
    if (seccion === 'usuarios') {
        cargarUsuarios();
    } else if (seccion === 'inventario') {
        cargarInventario(); 
    } else if (seccion === 'pedidos') {
        cargarPedidos();
    }
}

// ==========================================
// MÓDULO DE INVENTARIO
// ==========================================
async function cargarInventario() {
    try {
        const respuesta = await fetch(`${API_URL}/products`);
        const productos = await respuesta.json();
        listaProductosGlobal = productos; 
        renderizarTabla(productos);
    } catch (error) {
        console.error("Error al cargar inventario:", error);
    }
}

function renderizarTabla(productos) {
    const tbody = document.getElementById('tabla-productos-body');
    if(!tbody) return;
    tbody.innerHTML = '';

    productos.forEach(prod => {
        const imagenSegura = prod.image_url || 'https://placehold.co/100x100/1a1a1c/D4AF37?text=S';
        
        tbody.innerHTML += `
            <tr>
                <td><img src="${imagenSegura}" class="admin-thumb" style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;"></td>
                <td>
                    <div class="fw-bold">${prod.name}</div>
                    <small class="text-muted">${prod.brand || 'Originals'} | ${prod.section || 'General'}</small>
                </td>
                <td><span class="badge" style="background-color: #2A3143; color: var(--accent-gold);">${prod.gender || 'Unisex'}</span></td>
                <td><span class="badge border border-secondary text-light">${prod.category}</span></td>
                <td style="color: var(--accent-gold); font-weight: bold;">$${parseFloat(prod.price).toFixed(2)}</td>
                <td>
                    <button class="btn btn-sm btn-outline-light me-1" onclick="abrirModalEditar('${prod._id}')">✏️</button>
                    <button class="btn btn-sm btn-outline-danger" onclick="eliminarProducto('${prod._id}')">🗑️</button>
                </td>
            </tr>
        `;
    });
}

// Función auxiliar para leer cajas de texto sin que el código explote
const leerSiExiste = (idElemento, porDefecto = '') => {
    const elemento = document.getElementById(idElemento);
    return elemento ? elemento.value : porDefecto;
};

async function guardarProducto(e) {
    e.preventDefault();
    const chkOferta = document.getElementById('prod-oferta');

    const nuevoProducto = {
        name: leerSiExiste('prod-nombre'),
        gender: leerSiExiste('prod-genero', 'Unisex'),
        section: leerSiExiste('prod-seccion', 'Calzado'),
        category: leerSiExiste('prod-categoria'),
        price: parseFloat(leerSiExiste('prod-precio', 0)),
        description: leerSiExiste('prod-desc'),
        image_url: leerSiExiste('prod-img'),
        is_offer: chkOferta ? chkOferta.checked : false,
        brand: leerSiExiste('prod-marca', 'ShadowSport Originals')
    };

    try {
        const respuesta = await fetch(`${API_URL}/products`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify(nuevoProducto)
        });

        if (respuesta.ok) {
            bootstrap.Modal.getInstance(document.getElementById('modalNuevoProducto')).hide();
            document.getElementById('form-nuevo-producto').reset();
            cargarInventario();
            alert("✅ Producto guardado con éxito.");
        } else {
            const error = await respuesta.json();
            alert("❌ Error: " + (error.message || "No se pudo guardar"));
        }
    } catch (error) { console.error("Error al guardar:", error); }
}

async function eliminarProducto(id) {
    if(!confirm("¿Estás seguro de eliminar este producto?")) return;
    try {
        const respuesta = await fetch(`${API_URL}/products/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (respuesta.ok) cargarInventario(); 
    } catch (error) { console.error("Error al eliminar:", error); }
}

// === MÓDULO DE EDICIÓN BLINDADO ===
function abrirModalEditar(id) {
    const prod = listaProductosGlobal.find(p => p._id === id);
    if(!prod) return;

    const llenarSiExiste = (idElemento, valor) => {
        const elemento = document.getElementById(idElemento);
        if (elemento) elemento.value = valor;
    };

    llenarSiExiste('edit-id', prod._id);
    llenarSiExiste('edit-nombre', prod.name);
    llenarSiExiste('edit-genero', prod.gender || 'Unisex');
    llenarSiExiste('edit-seccion', prod.section || 'Calzado');
    llenarSiExiste('edit-categoria', prod.category);
    llenarSiExiste('edit-precio', prod.price);
    llenarSiExiste('edit-img', prod.image_url || '');
    llenarSiExiste('edit-desc', prod.description || '');
    llenarSiExiste('edit-marca', prod.brand || 'ShadowSport Originals');

    const chkOferta = document.getElementById('edit-oferta');
    if (chkOferta) chkOferta.checked = prod.is_offer || false;

    new bootstrap.Modal(document.getElementById('modalEditarProducto')).show();
}

document.getElementById('form-editar-producto').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = leerSiExiste('edit-id');
    const chkOferta = document.getElementById('edit-oferta');

    const datosActualizados = {
        name: leerSiExiste('edit-nombre'),
        gender: leerSiExiste('edit-genero', 'Unisex'),
        section: leerSiExiste('edit-seccion', 'Calzado'),
        category: leerSiExiste('edit-categoria'),
        price: parseFloat(leerSiExiste('edit-precio', 0)),
        description: leerSiExiste('edit-desc'),
        image_url: leerSiExiste('edit-img'),
        is_offer: chkOferta ? chkOferta.checked : false,
        brand: leerSiExiste('edit-marca', 'ShadowSport Originals')
    };

    try {
        const respuesta = await fetch(`${API_URL}/products/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify(datosActualizados)
        });

        if (respuesta.ok) {
            bootstrap.Modal.getInstance(document.getElementById('modalEditarProducto')).hide();
            cargarInventario();
            alert("✅ Producto actualizado con éxito.");
        } else { alert("❌ Error al actualizar el producto."); }
    } catch (error) { console.error("Error al actualizar:", error); }
});

// ==========================================
// MÓDULO DE USUARIOS Y ROLES
// ==========================================
async function cargarUsuarios() {
    const tbody = document.getElementById('tabla-usuarios-body');
    if(!tbody) return;
    tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4">Cargando usuarios...</td></tr>';

    try {
        const respuesta = await fetch(`${API_URL}/users`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (respuesta.ok) {
            listaUsuariosGlobal = await respuesta.json(); 
            renderizarUsuarios(listaUsuariosGlobal);
        } else {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Error de permisos.</td></tr>';
        }
    } catch (error) { console.error("Error de conexión:", error); }
}

function renderizarUsuarios(usuarios) {
    const tbody = document.getElementById('tabla-usuarios-body');
    if(!tbody) return;
    tbody.innerHTML = '';

    usuarios.forEach(user => {
        let badgeClass = "bg-secondary"; 
        let badgeStyle = "";
        let portalName = "Tienda Pública";

        if (user.role === 'admin') {
            badgeClass = "text-dark"; badgeStyle = "background-color: var(--accent-gold);"; portalName = "Intranet (Total)";
        } else if (user.role === 'proveedor') {
            badgeClass = "bg-info text-dark"; portalName = "Extranet (Inventario)";
        } else if (user.role === 'empleado') {
            badgeClass = "bg-success"; portalName = "Intranet (Ventas)";
        }

        tbody.innerHTML += `
            <tr>
                <td class="fw-bold">${user.email}</td>
                <td><span class="badge ${badgeClass}" style="${badgeStyle}">${(user.role || 'cliente').toUpperCase()}</span></td>
                <td><small class="text-muted">${portalName}</small></td>
                <td><span class="text-success small">● Activo</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-light me-1" onclick="abrirModalUsuario('${user._id}')">⚙️ Editar</button>
                    <button class="btn btn-sm btn-outline-danger" onclick="eliminarUsuario('${user._id}')">🗑️</button>
                </td>
            </tr>
        `;
    });
}

function abrirModalUsuario(id) {
    const user = listaUsuariosGlobal.find(u => u._id === id);
    if (!user) return;
    document.getElementById('edit-user-id').value = user._id;
    document.getElementById('edit-user-email').value = user.email;
    document.getElementById('edit-user-role').value = user.role || 'cliente';
    new bootstrap.Modal(document.getElementById('modalEditarUsuario')).show();
}

document.getElementById('form-editar-usuario').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('edit-user-id').value;
    const nuevoRol = document.getElementById('edit-user-role').value;

    try {
        const respuesta = await fetch(`${API_URL}/users/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
            body: JSON.stringify({ role: nuevoRol })
        });
        if (respuesta.ok) {
            bootstrap.Modal.getInstance(document.getElementById('modalEditarUsuario')).hide();
            cargarUsuarios(); 
        } else { alert("Error al actualizar permisos"); }
    } catch (error) { console.error(error); }
});

async function eliminarUsuario(id) {
    if(!confirm("⚠️ ¿Eliminar esta cuenta permanentemente?")) return;
    try {
        const respuesta = await fetch(`${API_URL}/users/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (respuesta.ok) cargarUsuarios();
    } catch (error) { console.error(error); }
}

// ==========================================
// MÓDULO DE PEDIDOS Y GRÁFICAS
// ==========================================
let chartVentas = null;

async function cargarPedidos() {
    const tbody = document.getElementById('tabla-pedidos-body');
    if(!tbody) return;
    tbody.innerHTML = '<tr><td colspan="5" class="text-center py-4">Cargando ventas...</td></tr>';

    try {
        const respuesta = await fetch(`${API_URL}/orders/todas`, {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        
        if (respuesta.ok) {
            const ordenes = await respuesta.json();
            renderizarPedidos(ordenes);
            dibujarGrafica(ordenes);
        } else {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-danger py-4">❌ Error al cargar historial.</td></tr>';
        }
    } catch (error) {
        console.error("Error:", error);
    }
}

function renderizarPedidos(ordenes) {
    const tbody = document.getElementById('tabla-pedidos-body');
    if(!tbody) return;
    tbody.innerHTML = '';

    if(ordenes.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted py-4">Aún no hay ventas registradas.</td></tr>';
        return;
    }

    ordenes.forEach(orden => {
        const fechaCruda = orden.date || orden.fecha_compra;
        const fecha = fechaCruda ? new Date(fechaCruda).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute:'2-digit' }) : 'Fecha desconocida';
        const montoTotal = orden.total || orden.total_pagado || 0;
        const cliente = orden.user_email || orden.cliente_id || 'Cliente Anónimo';
        const direccion = orden.shipping_address || 'Sin dirección registrada';
        
        tbody.innerHTML += `
            <tr>
                <td>
                    <div style="font-size: 0.8rem; color: #8A94A6;">${orden._id}</div>
                    <div class="fw-bold" style="font-size: 0.9rem;">${fecha}</div>
                </td>
                <td class="fw-bold">${cliente}</td>
                <td style="color: var(--accent-gold); font-weight: 900;">$${parseFloat(montoTotal).toFixed(2)}</td>
                <td><span class="badge bg-warning text-dark px-3 py-2">${(orden.status || 'PAGADO').toUpperCase()}</span></td>
                <td><small style="color: #A0ABC0;">${direccion}</small></td> 
            </tr>
        `;
    });
}

function dibujarGrafica(ordenes) {
    const canvasElement = document.getElementById('graficaVentas');
    if(!canvasElement) return;
    const ctx = canvasElement.getContext('2d');
    
    if(chartVentas) chartVentas.destroy();

    const ventasPorDia = {};
    ordenes.forEach(orden => {
        const fechaCruda = orden.date || orden.fecha_compra;
        if(!fechaCruda) return;
        
        const fechaSoloDia = new Date(fechaCruda).toLocaleDateString('es-ES', { day: '2-digit', month: 'short' });
        const monto = parseFloat(orden.total || orden.total_pagado || 0);
        
        if(ventasPorDia[fechaSoloDia]) {
            ventasPorDia[fechaSoloDia] += monto;
        } else {
            ventasPorDia[fechaSoloDia] = monto;
        }
    });

    const etiquetas = Object.keys(ventasPorDia).reverse();
    const datos = Object.values(ventasPorDia).reverse();

    chartVentas = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: etiquetas,
            datasets: [{
                label: 'Ingresos ($)',
                data: datos,
                backgroundColor: '#D4AF37',
                borderRadius: 6,
                maxBarThickness: 50
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { labels: { color: '#ffffff' } }
            },
            scales: {
                y: { 
                    ticks: { color: '#8A94A6' }, 
                    grid: { color: 'rgba(255,255,255,0.05)' } 
                },
                x: { 
                    ticks: { color: '#8A94A6' }, 
                    grid: { display: false } 
                }
            }
        }
    });
}

// ==========================================
// UTILIDADES
// ==========================================
function cerrarSesionAdmin() {
    localStorage.clear();
    window.location.href = 'login.html';
}