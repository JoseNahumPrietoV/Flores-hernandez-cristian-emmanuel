// ==========================================
// CONFIGURACIÓN INICIAL
// ==========================================
const API_URL = 'https://shadowsport.onrender.com/api';

// ==========================================
// FUNCIÓN PRINCIPAL DE REGISTRO
// ==========================================
async function registrarUsuario(event) {
    event.preventDefault(); // Evita que la página se recargue bruscamente

    // Capturamos los datos que escribió el usuario
    const nombre = document.getElementById('reg-nombre').value;
    const email = document.getElementById('reg-email').value;
    const password = document.getElementById('reg-password').value;
    const confirmPassword = document.getElementById('reg-confirm-password').value;
    
    // Capturamos las alertas y el botón
    const divError = document.getElementById('mensaje-error');
    const divExito = document.getElementById('mensaje-exito');
    const btnSubmit = document.getElementById('btn-submit');

    // Limpiamos mensajes anteriores
    divError.classList.add('d-none');
    divExito.classList.add('d-none');

    // Validación 1: Que las contraseñas coincidan
    if (password !== confirmPassword) {
        divError.innerText = "❌ Las contraseñas no coinciden.";
        divError.classList.remove('d-none');
        return;
    }

    // Efecto visual de carga
    btnSubmit.innerText = "CREANDO CUENTA...";
    btnSubmit.disabled = true;

    try {
        // ¡AQUÍ ESTÁ LA CORRECCIÓN! Apuntamos a /auth/register
        const respuesta = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                name: nombre, 
                email: email, 
                password: password,
                role: 'cliente' // Forzamos que nadie se registre como admin por accidente
            })
        });

        const data = await respuesta.json();

        if (respuesta.ok) {
            // Éxito: Todo salió bien
            divExito.innerText = "✅ ¡Cuenta creada con éxito! Redirigiendo...";
            divExito.classList.remove('d-none');
            document.getElementById('form-registro').reset();
            
            // Lo mandamos al login después de 2 segundos
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        } else {
            // Error de lógica (ej. El correo ya está registrado)
            divError.innerText = `❌ ${data.message || 'Error al crear la cuenta.'}`;
            divError.classList.remove('d-none');
            btnSubmit.innerText = "CREAR MI CUENTA";
            btnSubmit.disabled = false;
        }

    } catch (error) {
        // Error catastrófico (Servidor apagado)
        console.error("Error:", error);
        divError.innerText = "❌ No se pudo conectar con el servidor.";
        divError.classList.remove('d-none');
        btnSubmit.innerText = "CREAR MI CUENTA";
        btnSubmit.disabled = false;
    }
}