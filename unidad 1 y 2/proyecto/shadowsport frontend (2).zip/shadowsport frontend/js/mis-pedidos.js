// ==========================================
// CONFIGURACIÓN INICIAL
// ==========================================
const API_URL = 'https://shadowsport.onrender.com/api';
// Buscamos el "gafete" que se guardó cuando el usuario hizo Login
const token = localStorage.getItem('shadow_token'); 

// ==========================================
// FUNCIÓN PRINCIPAL: OBTENER MIS COMPRAS
// ==========================================
async function cargarMisPedidos() {
    const contenedor = document.getElementById('contenedor-pedidos');

    // 1. Si no tiene gafete, lo mandamos directo al login
    if (!token) {
        window.location.href = 'login.html';
        return;
    }

    try {
        // 2. Pedimos las órdenes a tu backend, MOSTRANDO el gafete en la cabecera
        const respuesta = await fetch(`${API_URL}/orders/mis-pedidos`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}` // ¡Aquí mostramos el gafete!
            }
        });

        if (respuesta.status === 401 || respuesta.status === 403) {
            // Si el gafete caducó o es falso, al login
            localStorage.removeItem('shadow_token');
            window.location.href = 'login.html';
            return;
        }

        const pedidos = await respuesta.json();

        // 3. Dibujamos los pedidos en pantalla
        renderizarPedidos(pedidos);

    } catch (error) {
        console.error("Error:", error);
        contenedor.innerHTML = '<div class="alert alert-danger">Error al conectar con el servidor.</div>';
    }
}

// ==========================================
// DIBUJAR LOS PEDIDOS
// ==========================================
function renderizarPedidos(pedidos) {
    const contenedor = document.getElementById('contenedor-pedidos');
    contenedor.innerHTML = '';

    if (pedidos.length === 0) {
        contenedor.innerHTML = `
            <div class="col-12 text-center py-5">
                <h4 style="color: #A0ABC0; font-weight: 600;">Aún no tienes pedidos. 📦</h4>
                <p class="text-muted">¡Es un gran día para empezar tu colección!</p>
                <a href="catalogo.html" class="btn btn-gold mt-3 px-4 py-2" style="background-color: var(--accent-gold); color: black; font-weight: bold; border-radius: 8px;">IR AL CATÁLOGO</a>
            </div>
        `;
        return;
    }

    // Dibujamos una tarjeta por cada compra
    pedidos.forEach(pedido => {
        // Formatear fecha
        const fecha = new Date(pedido.date).toLocaleDateString('es-MX', { 
            year: 'numeric', month: 'long', day: 'numeric' 
        });

        // Colores según el estado del pedido
        let colorEstado = '#8A94A6'; // Gris por defecto
        if(pedido.status === 'Pendiente de Envío') colorEstado = '#f1c40f'; // Amarillo
        if(pedido.status === 'En Camino') colorEstado = '#3498db'; // Azul
        if(pedido.status === 'Entregado') colorEstado = '#2ecc71'; // Verde

        // Dibujar los artículos de ese pedido
        let listaItems = '';
        if(pedido.items && pedido.items.length > 0) {
            pedido.items.forEach(item => {
                listaItems += `<div class="d-flex justify-content-between text-muted small border-bottom border-secondary pb-1 mb-1" style="border-color: rgba(255,255,255,0.05) !important;">
                                <span>${item.cantidad}x ${item.producto}</span>
                                <span style="color: var(--accent-gold);">$${item.precio.toFixed(2)}</span>
                               </div>`;
            });
        }

        contenedor.innerHTML += `
            <div class="col-md-6 mb-4">
                <div class="card h-100" style="background-color: var(--bg-card); border: 1px solid rgba(212, 175, 55, 0.1); border-radius: 16px;">
                    <div class="card-header border-0 pt-4 pb-2 px-4 d-flex justify-content-between align-items-center" style="background-color: transparent;">
                        <div>
                            <span class="small text-muted fw-bold d-block mb-1">ORDEN #${pedido._id.substring(0, 8).toUpperCase()}</span>
                            <span class="text-white">${fecha}</span>
                        </div>
                        <span class="badge" style="background-color: ${colorEstado}; color: black; font-weight: 800; padding: 8px 12px;">${pedido.status.toUpperCase()}</span>
                    </div>
                    <div class="card-body px-4">
                        <h6 class="text-white fw-bold mb-3">Artículos:</h6>
                        <div class="mb-4">
                            ${listaItems}
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-auto pt-3 border-top" style="border-color: rgba(212, 175, 55, 0.1) !important;">
                            <span class="text-muted fw-bold small">TOTAL PAGADO</span>
                            <span class="fs-4 fw-bold" style="color: var(--accent-gold);">$${pedido.total.toFixed(2)}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    });
}

// Arrancamos
cargarMisPedidos();