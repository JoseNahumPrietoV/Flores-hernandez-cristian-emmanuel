// ==========================================
// js/carrito.js - MOTOR DEL CARRITO
// ==========================================

// ¡NUEVO!: Declaramos la ruta de tu servidor para que Stripe funcione
const API_URL = 'https://shadowsport.onrender.com/api';

// 1. Cargar el carrito
let carrito = [];
try {
    carrito = JSON.parse(localStorage.getItem('shadow_carrito')) || [];
} catch (e) {
    carrito = [];
}

let porcentajeDescuento = 0; 

// 2. Función principal
function renderizarCarrito() {
    const contenedor = document.getElementById('contenedor-carrito');
    const subtotalElement = document.getElementById('resumen-subtotal');
    const totalElement = document.getElementById('resumen-total');
    const filaDescuento = document.getElementById('fila-descuento');
    const descuentoPrecio = document.getElementById('descuento-precio');
    const totalOriginalElement = document.getElementById('total-original');
    const contenedorAhorro = document.getElementById('contenedor-ahorro');
    const textoAhorro = document.getElementById('texto-ahorro');

    if (!contenedor) return;

    if (carrito.length === 0) {
        contenedor.innerHTML = `
            <div class="text-center py-5">
                <h4 class="text-muted mb-4">Tu carrito de alto rendimiento está vacío.</h4>
                <a href="index.html" class="btn btn-shadowsport px-5 py-3">VOLVER A LA TIENDA</a>
            </div>`;
        if(subtotalElement) subtotalElement.innerText = '$0.00';
        if(totalElement) totalElement.innerText = '$0.00';
        if(filaDescuento) filaDescuento.style.setProperty('display', 'none', 'important');
        if(contenedorAhorro) contenedorAhorro.style.display = 'none';
        if(totalOriginalElement) totalOriginalElement.style.display = 'none';
        actualizarContadorNav();
        return;
    }

    contenedor.innerHTML = '';
    
    let subtotal = 0;
    carrito.forEach(item => {
        subtotal += (parseFloat(item.precio) || 0) * (parseInt(item.cantidad) || 1);
    });

    carrito.forEach((item, index) => {
        const precio = parseFloat(item.precio) || 0;
        const cantidad = parseInt(item.cantidad) || 1;
        const precioTotalItem = precio * cantidad;
        
        const precioConDescuentoItem = precioTotalItem * (1 - porcentajeDescuento);

        let htmlPrecioVisual = '';
        if (porcentajeDescuento > 0) {
            htmlPrecioVisual = `
                <div class="text-decoration-line-through mb-1" style="color: rgba(255, 255, 255, 0.6); font-size: 0.95rem;">$${precioTotalItem.toFixed(2)}</div>
                <div class="fw-bold fs-5" style="color: var(--accent-gold);">$${precioConDescuentoItem.toFixed(2)}</div>
            `;
        } else {
            htmlPrecioVisual = `
                <div class="fw-bold fs-5" style="color: var(--accent-gold);">$${precioTotalItem.toFixed(2)}</div>
            `;
        }

        contenedor.innerHTML += `
            <div class="product-card d-flex align-items-center flex-wrap flex-md-nowrap gap-3">
                <img src="${item.imagen}" class="img-producto" alt="${item.producto}">
                <div class="flex-grow-1">
                    <div class="d-flex justify-content-between align-items-start">
                        <div>
                            <h5 class="fw-bold mb-1 text-white">${item.producto}</h5>
                            <p class="small mb-3" style="color: var(--text-muted);">Categoría Premium</p>
                        </div>
                        <div class="text-end">
                            ${htmlPrecioVisual}
                        </div>
                    </div>
                    
                    <div class="d-flex align-items-center justify-content-between mt-2">
                        <div class="qty-control">
                            <button class="qty-btn fs-5" onclick="cambiarCantidad(${index}, -1)">-</button>
                            <span class="fw-bold px-2">${cantidad}</span>
                            <button class="qty-btn fs-5" onclick="cambiarCantidad(${index}, 1)">+</button>
                        </div>
                        <button class="btn btn-link p-0 btn-eliminar" onclick="eliminarDelCarrito(${index})">
                            ELIMINAR
                        </button>
                    </div>
                </div>
            </div>
        `;
    });

    const descuentoAplicado = subtotal * porcentajeDescuento;
    const totalFinal = subtotal - descuentoAplicado;

    if(subtotalElement) subtotalElement.innerText = `$${subtotal.toFixed(2)}`;

    if (porcentajeDescuento > 0) {
        if(filaDescuento) filaDescuento.style.setProperty('display', 'flex', 'important');
        if(descuentoPrecio) descuentoPrecio.innerText = `-$${descuentoAplicado.toFixed(2)}`;
        
        if(totalOriginalElement) {
            totalOriginalElement.innerText = `$${subtotal.toFixed(2)}`;
            totalOriginalElement.style.display = 'block';
        }
        if(contenedorAhorro && textoAhorro) {
            textoAhorro.innerText = descuentoAplicado.toFixed(2);
            contenedorAhorro.style.display = 'block';
        }
        if(totalElement) totalElement.innerText = `$${totalFinal.toFixed(2)}`;
    } else {
        if(filaDescuento) filaDescuento.style.setProperty('display', 'none', 'important');
        if(totalOriginalElement) totalOriginalElement.style.display = 'none';
        if(contenedorAhorro) contenedorAhorro.style.display = 'none';
        if(totalElement) totalElement.innerText = `$${subtotal.toFixed(2)}`;
    }
    
    actualizarContadorNav();
}

// 3. Controles
function cambiarCantidad(index, cambio) {
    carrito[index].cantidad += cambio;
    if (carrito[index].cantidad <= 0) {
        carrito.splice(index, 1);
    }
    localStorage.setItem('shadow_carrito', JSON.stringify(carrito));
    aplicarCuponSilencioso(); 
    renderizarCarrito();
}

function eliminarDelCarrito(index) {
    carrito.splice(index, 1);
    localStorage.setItem('shadow_carrito', JSON.stringify(carrito));
    aplicarCuponSilencioso();
    renderizarCarrito();
}

// 4. Sistema de Cupones Actualizado a Porcentajes
function aplicarCupon() {
    const inputElement = document.getElementById('input-cupon');
    const mensajeElement = document.getElementById('mensaje-cupon');
    if (!inputElement || !mensajeElement) return;

    const codigo = inputElement.value.trim().toUpperCase();

    if (codigo === 'SHADOW20') {
        porcentajeDescuento = 0.20; // 20%
        mensajeElement.innerText = "¡Éxito! Cupón de 20% aplicado.";
        mensajeElement.style.color = "var(--accent-gold)";
    } 
    else if (codigo === 'BIENVENIDA') {
        porcentajeDescuento = 0.10; // 10%
        mensajeElement.innerText = "¡Éxito! Cupón de 10% aplicado.";
        mensajeElement.style.color = "var(--accent-gold)";
    }
    else if (codigo === '') {
        porcentajeDescuento = 0;
        mensajeElement.innerText = "";
    }
    else {
        porcentajeDescuento = 0;
        mensajeElement.innerText = "Código inválido o expirado.";
        mensajeElement.style.color = "#ff3b4d"; 
    }
    renderizarCarrito();
}

function aplicarCuponSilencioso() {
    const inputElement = document.getElementById('input-cupon');
    if (!inputElement) return;
    const codigo = inputElement.value.trim().toUpperCase();

    if (codigo === 'SHADOW20') porcentajeDescuento = 0.20;
    else if (codigo === 'BIENVENIDA') porcentajeDescuento = 0.10;
    else porcentajeDescuento = 0;
}

function actualizarContadorNav() {
    const contador = document.getElementById('btn-carrito-nav');
    if(contador) {
        const totalArticulos = carrito.reduce((acc, item) => acc + (parseInt(item.cantidad) || 0), 0);
        contador.innerText = `🛒 Carrito (${totalArticulos})`;
    }
}

// 5. Arrancar
document.addEventListener("DOMContentLoaded", () => {
    aplicarCuponSilencioso(); 
    renderizarCarrito();
});

// ==========================================
// 6. PASARELA DE PAGOS REAL - STRIPE
// ==========================================
// ¡Eliminamos la vieja función falsa y dejamos solo la de Stripe!
async function procesarPagoStripe() {
    if (carrito.length === 0) {
        alert("Tu carrito está vacío. ¡Agrega unos tenis primero!");
        return;
    }

    const btnPagar = document.getElementById('btn-pagar-carrito');
    
    // Si tu botón HTML no tiene ese ID, evitamos que marque error
    if(btnPagar) {
        btnPagar.innerText = "Conectando al banco...";
        btnPagar.disabled = true;
    } else {
        console.warn("⚠️ Advertencia: No se encontró un botón con id='btn-pagar-carrito'");
    }

    try {
        const respuesta = await fetch(`${API_URL}/create-checkout-session`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ carrito: carrito })
        });

        const data = await respuesta.json();

        if (data.url) {
            window.location.href = data.url; 
        } else {
            console.error("Error de Stripe:", data.error);
            alert("Hubo un problema al generar el cobro.");
            if(btnPagar) { btnPagar.innerText = "PROCEDER AL PAGO"; btnPagar.disabled = false; }
        }
    } catch (error) {
        console.error("Error de conexión:", error);
        alert("Error al conectar con el servidor.");
        if(btnPagar) { btnPagar.innerText = "PROCEDER AL PAGO"; btnPagar.disabled = false; }
    }
} 

// ==========================================
// REDIRECCIÓN AL CHECKOUT
// ==========================================
function procesarPago() {
    if (carrito.length === 0) {
        alert("Tu carrito está vacío. ¡Agrega unos tenis primero!");
        return;
    }
    // Redirige a la pantalla donde piden la dirección
    window.location.href = 'checkout.html';
}